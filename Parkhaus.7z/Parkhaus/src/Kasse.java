import java.util.Scanner;

public class Kasse {
	public static void main(String[] args) {
		
		Ticket t1 =new Ticket(); 
		
		
		System.out.println(t1.getDatEingang());
		
		
		
		
		
		
	}
	
}
